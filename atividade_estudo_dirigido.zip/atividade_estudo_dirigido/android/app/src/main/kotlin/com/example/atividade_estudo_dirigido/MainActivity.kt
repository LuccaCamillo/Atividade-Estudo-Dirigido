package com.example.atividade_estudo_dirigido

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
