import 'package:atividade_estudo_dirigido/Tela2.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("PSN Store"),
      ),
      body: Column(
        children: <Widget>[
          Image.asset("images/logo.png",
            fit: BoxFit.cover,
          ),
          Padding(padding: EdgeInsets.all(30),
            //ignore: deprecated_member_use
            child: RaisedButton(
              color: Colors.blue,
              textColor: Colors.white,
              padding: EdgeInsets.all(15),
              child: Text(
                "Entrar na Loja",
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context)=>Tela2()),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
