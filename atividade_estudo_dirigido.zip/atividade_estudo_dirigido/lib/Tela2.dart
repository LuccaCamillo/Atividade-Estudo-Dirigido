import 'package:atividade_estudo_dirigido/Tela3.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class Tela2 extends StatefulWidget {
  const Tela2({Key? key}) : super(key: key);

  @override
  _Tela2State createState() => _Tela2State();
}

class _Tela2State extends State<Tela2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Loja"),
      ),
      body: ListView(
        children: [
          Image.asset("images/cima.jpg",
            fit: BoxFit.cover,
          ),
          Image.asset("images/meio.jpg",
            fit: BoxFit.fill,
          ),
          Image.asset("images/baixo.jpg",
            fit: BoxFit.fill,
          ),
          Padding(
              padding: EdgeInsets.all(32)),
          Center(
            child: ElevatedButton.icon(
              onPressed: (){
                Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context)=>Elevated()));
              },
              icon: Icon(Icons.arrow_right),
              label: Text('Ver Lançamentos'),

            ),
          ),
          Padding(
              padding: EdgeInsets.all(10)),
        ],
      ),
    );
  }
}

class Elevated extends StatefulWidget {
  const Elevated({Key? key}) : super(key: key);

  @override
  _ElevatedState createState() => _ElevatedState();
}

class _ElevatedState extends State<Elevated> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Laçamentos e mais...'),
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.contacts),
            title: Text('Lançamentos'),
            onTap: (){
              Navigator.push(context,
                  MaterialPageRoute(builder: (context)=>Tela3()));
            },
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text('Perfil'),
          ),
          ListTile(
            leading: Icon(Icons.settings),
            title: Text('Configurações'),
          ),
          Image.asset("images/meio.jpg",
            fit: BoxFit.cover,
          ),
          Padding(padding: EdgeInsets.all(32)),
          Center(
            child: ElevatedButton.icon(
              onPressed: (){
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back),
              label: Text('Voltar'),
            ),

          ),
        ],
      ),
    );
  }
}
