import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:atividade_estudo_dirigido/Home.dart';

void main() {
  runApp(MaterialApp(
    home: Home(),
  ));
}