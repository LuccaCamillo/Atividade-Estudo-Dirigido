import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class Tela3 extends StatefulWidget {
  const Tela3({Key? key}) : super(key: key);

  @override
  _Tela3State createState() => _Tela3State();
}

class _Tela3State extends State<Tela3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Lançamentos"),
      ),
      body: ListView(
        children: [
          Image.asset(
            "images/baixo.jpg",
            fit: BoxFit.cover,
          ),
          Image.asset(
            "images/meio.jpg",
            fit: BoxFit.fill,
          ),
          Image.asset(
            "images/cima.jpg",
            fit: BoxFit.fill,
          ),
          Image.asset(
            "images/meio.jpg",
            fit: BoxFit.fill,
          ),
          //ignore: deprecated_member_use
          RaisedButton(
            color: Colors.blueAccent,
            textColor: Colors.white,
            padding: EdgeInsets.all(15),
            child: Text(
              "Voltar",
              style: TextStyle(
                fontSize: 20,
              ),
            ),
            onPressed: () {
              Navigator.pop(context);
            },

          ),
        ],
      ),
    );
  }
}
